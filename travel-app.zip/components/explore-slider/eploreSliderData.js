export const exploreSliderData = [
  {
    title: "Swat, Kalam, Malam Jabba",
    description: "Swat, Kalam, Malam Jabba & Ushu Forest Tour 5 Days 4 Nights",
    rating: 4.35,
    badge: "ITINERARY",
    image: "/images/1.jpg",
  },
  {
    title: "Swat, Kalam, Malam Jabba",
    description: "Swat, Kalam, Malam Jabba & Ushu Forest Tour 5 Days 4 Nights",
    rating: 3.09,
    badge: "ITINERARY",
    image: "/images/2.jpg",
  },
  {
    title: "Swat, Kalam, Malam Jabba",
    description: "Swat, Kalam, Malam Jabba & Ushu Forest Tour 5 Days 4 Nights",
    rating: 4.9,
    badge: "ITINERARY",
    image: "/images/3.jpg",
  },
  {
    title: "Swat, Kalam, Malam Jabba",
    description: "Swat, Kalam, Malam Jabba & Ushu Forest Tour 5 Days 4 Nights",
    rating: 4.2,
    badge: "ITINERARY",
    image: "/images/4.jpg",
  },
  {
    title: "Swat, Kalam, Malam Jabba",
    description: "Swat, Kalam, Malam Jabba & Ushu Forest Tour 5 Days 4 Nights",
    rating: 3.6,
    badge: "ITINERARY",
    image: "/images/5.jpg",
  },
  {
    title: "Swat, Kalam, Malam Jabba",
    description: "Swat, Kalam, Malam Jabba & Ushu Forest Tour 5 Days 4 Nights",
    rating: 5,
    badge: "ITINERARY",
    image: "/images/6.jpg",
  },
];
