<template>
  <div>
    <Header></Header>
    <h1>Destinations Page</h1>
  </div>
</template>

<script lang="ts" setup></script>

<style scoped></style>
