<template>
  <div>
    <Header></Header>
    <h1>About Page</h1>
  </div>
</template>

<script lang="ts" setup>
useHead({
  title: "Nuxt App :: About",
});
</script>

<style scoped></style>
