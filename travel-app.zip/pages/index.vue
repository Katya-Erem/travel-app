<template>
  <div>
    <BannerHome />
    <div class="w-full min-h-screen bg-slate-50">
      <div class="container mx-auto">
        <!-- <ExploreSlider /> -->
      </div>
    </div>
  </div>
</template>

<script setup>
// import ExploreSlider from "../components/explore-slider/ExploreSlider.vue";

useHead({
  title: "Home Page",
});
</script>
